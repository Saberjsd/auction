export const getMsg = (state, payload) => {
    state.msg = payload.msg;
  }