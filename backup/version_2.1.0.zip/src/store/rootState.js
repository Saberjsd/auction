const state = {
    msg: '我是原始数据',
  }
  export default state;