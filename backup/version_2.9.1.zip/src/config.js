const reslult={
    str:"kiCkyouRassfUckyou",
    key:"1wuLwy6Fd7",
}
export default reslult;