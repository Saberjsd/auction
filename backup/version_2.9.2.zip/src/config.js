const reslult={
    str:"kiCkyouRassfUckyou",
    key:"1wuLwy6Fd7",
    ku:'6f63f5895e9fd83e0',
}
export default reslult;