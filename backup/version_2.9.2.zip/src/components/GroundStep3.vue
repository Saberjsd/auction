<template>
  <div class="infoWindow">
    <div class="info-head">
      <i @click="goArea" v-if="$store.state.sidebars =='01'"></i>
      <span @click="$store.dispatch('setGroundShowDetail')">
        地块信息
        <em :class="{active:!$store.state.groundShowDetail}"></em>
      </span>
      <b :class="{collection:true,active:$store.state.landIsCollected}" @click="collectionClick"></b>
    </div>

    <el-collapse-transition>
      <div class="info-body" v-show="$store.state.groundShowDetail" >
        <ul class="info-msg">
          <li><i></i>地块编号 <span>{{$store.getters.currentGround.signId}}</span></li>
          <li><i></i>地块类型 <span>{{$store.getters.currentGround.classify?$store.getters.currentGround.classify:'标志地块'}}</span></li>
          <li><i></i>地块状态 <span>{{states[$store.getters.currentGround.state]}}</span></li>
          
          <template v-if="priceList.length >0" v-loading="PriceLoading">
            <li style="border-bottom:none;"><i></i>出价记录</li>
            <div class="price-list acted">
              <li v-for="item in priceList" :key="item.userId">
                <span >{{item.walletAddr}} </span>
                <span v-if="item.price" class="ddc">{{item.price}} DDC &nbsp;&nbsp;<i v-if="item.walletAddr==$store.state.userInfo.walletAddr">(我)</i></span>
                <span>{{dateFormat(item.priceTime,'M-dd hh:mm:ss')}}</span>
              </li>
            </div>
          </template>

          <li ><i></i>地块拥有者 </li>
          <div class="ground-owner">
            <span>{{owner}}</span>
          </div>
        </ul>

        

      </div>
    </el-collapse-transition>

  </div>
</template>

<script>
import dateFormat from "@/util/dateF";
export default {
  name: "GroundStep1",
  data() {
    return {
      inputPrice: "",
      //  collectionActive:false,
      states: ["未开拍", "拍卖中", "已拍卖 待支付", "已拍卖 已支付"],
      owner: "",
      dateFormat
    };
  },
  props: ["landid", "priceList","PriceLoading"],
  mounted() {
    if (this.landid) {
      this.get_owner();
    }
  },
  watch: {
    landid: function(val, old) {
      this.get_owner();
    }
  },
  methods: {
    get_owner() {
      var land = this.$store.getters.currentGround;
      console.log('land',land)
      // if(land.userId){
      //   if(land.userId == 0){
      //     land.addr ='系统账户'
      //   }else{
      //     this.$http
      //     .get("/auction/api/user/getWalletAddrById", {
      //       params: {
      //         userId: this.$store.state.userInfo.id
      //       },
      //       timeOut: 5000
      //     })
      //     .then(res => {
      //       if (res.data.code == 1) {
      //         console.log(res.data)
      //         this.owner = res.data.data;
      //         // this.$store.dispatch("setCurrentland",{id:land.id,data:land});
      //       }
      //     });
      //   }
      // }
      if (land.addr) {
        this.owner = land.addr;
        console.log(111)
      } else if (land.userId == 0) {
        this.owner = "系统账户";
        console.log(222)
      } else if(land.userId >0){
        console.log(333)
        this.$http
          .get("/auction/api/user/getWalletAddrById", {
            params: {
              userId: this.$store.state.userInfo.id
            },
            timeOut: 5000
          })
          .then(res => {
            if (res.data.code == 1) {
              land.addr= res.data.data;
              this.owner = res.data.data;
              this.$store.dispatch("setCurrentland",{id:land.id,data:land});
            }
          });
      }
    },
    collectionClick() {
      var vthis = this;
      if (!this.$store.state.landIsCollected) {
        // console.log
        this.$http
          .get("/auction/api/collect/collectLand", {
            params: {
              userId: this.$store.state.userInfo.id,
              landId: this.$store.state.currentGroundID
            },
            timeOut: 5000
          })
          .then(function(res) {
            if (res.data.code == 1) {
              // vthis.$store.dispatch('setGroundDetailCollection',true)
              vthis.$store.dispatch("setData", {
                state: "landIsCollected",
                data: true
              });
              // vthis.collectionActive = true
              vthis.$message({
                showClose: true,
                message: "收藏成功",
                type: "success"
              });
            } else {
              vthis.$message({
                showClose: true,
                message: "您已经收藏过了",
                type: "error"
              });
            }
          })
          .catch(function(err) {
            vthis.$message({
              showClose: true,
              message: err.message,
              type: "error"
            });
          });
      } else {
        this.$http
          .get("/auction/api/collect/cancelCollect", {
            params: {
              userId: this.$store.state.userInfo.id,
              landId: this.$store.state.currentGroundID
            },
            timeOut: 5000
          })
          .then(function(res) {
            if (res.data.code == 1) {
              // vthis.collectionActive = false
              vthis.$store.dispatch("setData", {
                state: "landIsCollected",
                data: false
              });
              vthis.$message({
                showClose: true,
                message: "取消收藏成功",
                type: "success"
              });
            } else {
              vthis.$message({
                showClose: true,
                message: "取消收藏失败",
                type: "error"
              });
            }
          })
          .catch(function(err) {
            vthis.$message({
              showClose: true,
              message: err.message,
              type: "error"
            });
          });
      }
    },
    goArea: function() {
      this.$emit("goArea", "1");
      this.$store.dispatch("setData", { state: "groundIn", data: false });
    }
  }
};
</script>
<style scoped>

</style>
